# ConrolFanByUsingGUI-TempSensor
By using the desktop app, using the C # language, you can control the operation of the fan and increase its speed when the temperature increases

<img width="325" alt="Capt4ure" src="https://user-images.githubusercontent.com/48031643/96790419-0ebc3f80-13f7-11eb-86d9-c79051f9ff9d.PNG">

<img width="312" alt="fane" src="https://user-images.githubusercontent.com/48031643/96790583-55119e80-13f7-11eb-9ee1-1e2db5922b09.PNG">
